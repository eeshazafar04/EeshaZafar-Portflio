const naam = (cityName) => {

    let p = fetch(`https://api.openweathermap.org/data/2.5/weather?q=karachi&appid=f3d74fe7c4cf5b26d596c7f0f988d7a6&units=metric`)
    p.then((value1) => {
        return value1.json()
    }).then((value2) => {
        console.log(value2)
        getWeatherDetails(value2.name, value2.coord.lat, value2.coord.lon);
        let temps = value2.main.temp
        document.getElementById("temp").innerHTML = `${temps}°C`

        let hum = value2.main.humidity
        document.getElementById("humid").innerHTML = `${hum}%`

        let pres = value2.main.pressure
        document.getElementById("prsr").innerHTML = `${pres}%`

        let maxim = value2.main.temp_max
        document.getElementById("max").innerHTML = `${maxim}°C`
        let minim = value2.main.temp_min
        document.getElementById("min").innerHTML = `${minim}°C`

        let city = value2.name
        document.getElementById("city").innerHTML = `${city}`



    })
}
naam()


const cityInput = document.querySelector(".city-input").value;
const searchButton = document.querySelector(".search-btn");

const currentWeatherDiv = document.querySelector(".current-weather");
const weatherCardsDiv = document.querySelector(".weather-cards");

const API_KEY = "f3d74fe7c4cf5b26d596c7f0f988d7a6";

const createWeatherCard = (cityName, weatherItem, index) => {

    return `
        <div class="current-weather card-body forcast_wala ">
           <h4 class="card-title pricing-card-title">(${weatherItem.dt_txt.split(" ")[0]})</h4>
                <ul class="list-unstyled mt-3 mb-4 ">
                  
                  <h6>Temperature: ${(weatherItem.main.temp - 273.15).toFixed(2)}°C</h6>
                  <h6>Wind: ${weatherItem.wind.speed} m/s</h6>
                  <h6>Humidity: ${weatherItem.main.humidity}%</h6>
                </ul>
                
              </div>
      
        `;
}

const getWeatherDetails = (cityName, latitude, longitude) => {
    console.log("agaya", longitude, latitude, cityName)
    const WEATHER_API_URL = `https://api.openweathermap.org/data/2.5/forecast?lat=${latitude}&lon=${longitude}&appid=${API_KEY}`;

    fetch(WEATHER_API_URL).then(response => response.json()).then(data => {
        // Filter the forecasts to get only one forecast per day
        console.log("eeee", data)
        const uniqueForecastDays = [];
        const fiveDaysForecast = data.list.filter(forecast => {
            const forecastDate = new Date(forecast.dt_txt).getDate();
            if (!uniqueForecastDays.includes(forecastDate)) {
                return uniqueForecastDays.push(forecastDate);
            }
        });

        // Clearing previous weather data
        cityInput.value = "";
        currentWeatherDiv.innerHTML = "";
        weatherCardsDiv.innerHTML = "";
        console.log("3 days forcast", fiveDaysForecast);
        // Creating weather cards and adding them to the DOM
        fiveDaysForecast.forEach((weatherItem, index) => {
            const html = createWeatherCard(cityName, weatherItem, index);
            if (index === 0) {
                currentWeatherDiv.insertAdjacentHTML("beforeend", html);
            } else {
                weatherCardsDiv.insertAdjacentHTML("beforeend", html);
            }
        });
    })

}

const getCityCoordinates = () => {
    const cityName = cityInput.value.trim();
    if (cityName === "") return;
    const API_URL = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=f3d74fe7c4cf5b26d596c7f0f988d7a6&units=metric`;


    fetch(API_URL).then(response => response.json()).then(data => {
        if (!data.length) return alert(`No coordinates found for ${cityName}`);
        const { lat, lon } = data.coord;
        console.log(lat, lon, data.name);
        getWeatherDetails(data.name, lat, lon);
    }).catch(() => {
        alert("An error occurred while fetching the coordinates!");
    });
}


console.log(cityInput);

searchButton.addEventListener("click", naam);
cityInput.addEventListener("keyup", e => e.key === "Enter" && naam());

